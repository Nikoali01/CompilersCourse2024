package node;

public abstract class ASTNode {}
