package node;

public class TypeNode extends ASTNode {
    String typeName;

    public TypeNode(String typeName) {
        this.typeName = typeName;
    }
}
